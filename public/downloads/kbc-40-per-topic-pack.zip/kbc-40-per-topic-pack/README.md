# KBC / Crorepati Revision — 40 Questions Per Topic Pack

**13,800 questions · 345 topics · 26 subjects · 82 chapters · 10 exams**

Every topic in the catalogue carries **exactly 40 four-option bilingual (English + Hindi)
questions**, grouped into the chapter that the syllabus assigns it to.

| Item | Count |
| --- | ---: |
| Subjects | 26 |
| Chapters | 82 |
| Topics | 345 |
| Active questions | **13,800** (345 × 40) |
| Preserved archive (SI-free) | 1,895 |
| SI-unit questions converted to MCQs | 400 |
| Exam profiles | 10 |

---

## What is in each folder

### `01_all_questions/starter.json`
The complete bank in one file — 13,800 questions, plus 345 fact cards and the source list.
This is the same file the web app serves.

Each question looks like this:

```json
{
  "id": "G_S01-C8994e811-T60e40ec2_012",
  "subjectId": "S01",
  "chapterId": "S01-C8994e811",
  "topicId": "S01-C8994e811-T60e40ec2",
  "question": { "en": "…", "hi": "…" },
  "options": [
    { "en": "…", "hi": "…" },
    { "en": "…", "hi": "…" },
    { "en": "…", "hi": "…" },
    { "en": "…", "hi": "…" }
  ],
  "correctIndex": 2,
  "difficulty": "EASY | MEDIUM | HARD",
  "angle": "FACT_RECALL",
  "explanation": { "en": "…", "hi": "…" },
  "factCardIds": ["FC_…"],
  "sourceUrl": "…",
  "kind": "ACTUAL_PYQ | FACT_DERIVED"
}
```

IDs starting with `Q_` are the original verified bank; `G_` are the newly generated ones.

### `02_by_chapter_all_subjects/<subjectId>/<chapterId>.json`
**This is the "saved into every chapter" layout.** One file per chapter, containing
`topics[]`, each with its 40 full question records — exactly as the syllabus groups them.

### `03_by_exam/<examId>/<subjectId>/<chapterId>.json`
The same chapters cut down to the subjects that exam covers, with per-topic
`questionIds` (40 each) and a `questionsFile` pointer back to the full records
in `02_by_chapter_all_subjects`. Exams and their reach:

| Exam | Subjects | Topics | Questions |
| --- | ---: | ---: | ---: |
| all / kbc / ssc-cgl | 26 | 345 | 13,800 |
| upsc-cse / hcs | 25 | 335 | 13,400 |
| railway-ntpc | 24 | 327 | 13,080 |
| sbi-po / ibps-po | 9 | 118 | 4,720 |
| rbi-grade-b / apfc | 8 | 108 | 4,320 |

### `04_si_unit_mcqs/`
Every SI-unit question, converted to a four-option MCQ in **left question / right
options** layout:

- `si-unit-mcqs.json` — `layout: "left-question-right-options"`, `originalId`, `origin`
  (`ACTIVE` or `PRESERVED`), `removedFromPreserved`, four bilingual options, answer key.
- `si-unit-mcqs.md` — human-readable, one table row per question:
  the question on the left, the four options on the right.
- `si_unit_mcqs_400.csv` — the same 400 rows for Excel.

### `05_preserved_bank_si_free/`
`preserved-bank.json` is the archive with `policy: "SI_UNITS_EXCLUDED"` —
**zero SI-unit questions remain**. It counts the 50 SI records it removed.
`preserved_1895.csv` is the spreadsheet version.

> Note: the project's original 14,016-record archive was never committed to the repo.
> This pack contains every archive record that exists in the checkout (the 1,725-question
> verified bank + the Harappan/Prehistory Markdown banks + the legacy banks). Drop the real
> archive at `data/preserved-bank.json` and re-run `node scripts/build-data.mjs` to merge it.

### `06_syllabus/`
- `syllabus-index.json` — exam → subject → chapter → topic coverage with `questionCount`,
  `target: 40` and `status` for every topic.
- `catalog.json` — the catalogue with per-topic and per-subject question counts.

### `07_reports/`
- `data-report.json` — measured counts and the SI removal ledger.
- `validation.json` — the 9 acceptance checks (all passing).
- `OUTPUT_SAMPLE.md` — one full worked example per subject.

### `08_spreadsheet/`
`all_13800_questions.csv` — all 13,800 questions flattened to one row each
(UTF-8 with BOM, so Hindi renders correctly in Excel). Columns:

`subject_id, subject_en, subject_hi, chapter_id, chapter_en, chapter_hi, topic_id,
topic_en, topic_hi, question_id, question_en, question_hi, option_a_en … option_d_hi,
correct_index, correct_letter, answer_en, answer_hi, explanation_en, explanation_hi,
difficulty, angle, kind`

---

## How the questions were generated

> **Ollama was not available in the build environment** (no `ollama` binary, nothing on
> port 11434). Generation therefore used the repository's deterministic, fact-grounded
> offline engine, which derives each question from the topic's verified catalogue concepts
> and fact card — output is marked `kind: "FACT_DERIVED"`, `generator: "offline-fact-v2"`.

To regenerate with a real model:

```bash
ollama pull gemma3:4b
node scripts/generate.mjs --engine ollama --model gemma3:4b --target 40 --force
node scripts/build-data.mjs
```

`--engine auto` uses Ollama when it is reachable and falls back to offline otherwise.

## Regenerating / verifying

```bash
npm install
npm run build:data      # rebuild every JSON/CSV source of this pack
npm run validate        # 9 acceptance checks, exits non-zero on failure
npm test                # 6 data invariants
```
