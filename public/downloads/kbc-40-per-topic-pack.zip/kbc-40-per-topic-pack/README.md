# KBC question pack — 13,800 questions

**26 subjects · 82 chapters · 345 topics · exactly 40 questions per topic.**

Start with **START-HERE.html** — it links to everything and shows the counts.

| Folder | What it holds |
| --- | --- |
| `1_READ_QUESTIONS_HTML/` | 26 subject pages + an index. Read every question in a browser, no tools needed. |
| `2_SPREADSHEETS/` | The master CSV (all 13800 questions, 28 columns, English + Hindi), SI MCQs, the preserved bank, one CSV per subject (26) and per exam (10 distinct syllabuses). |
| `3_JSON_FULL_BANK/` | The complete bank as one JSON file. |
| `4_JSON_BY_CHAPTER/` | 82 chapter files — each topic's 40 questions inline. |
| `5_JSON_BY_EXAM/` | 591 exam-filtered files pointing at the chapter files. |
| `6_SI_UNIT_MCQS/` | The 400 SI MCQs in left-question/right-options layout, JSON + Markdown. |
| `7_PRESERVED_SI_FREE/` | 1895 archive records, zero SI. |
| `8_SYLLABUS/` | Exam → subject → chapter → topic coverage. |
| `9_REPORTS/` | Build report, validation report, worked sample. |
| `CHECK-REPORT.md` | Measured counts and pass/fail for every acceptance rule. |
| `MANIFEST.txt` | Every file in the pack with its size. |

## Verify

1. Open `CHECK-REPORT.md` — expect 13800 questions, 345 topics, 345 at exactly 40.
2. Open `1_READ_QUESTIONS_HTML/index.html` and pick any subject.
3. Open `2_SPREADSHEETS/ALL-13800-questions.csv` in Excel — 13800 data rows.
4. `MANIFEST.txt` lists every file with its byte size, plus the grand total.

## About generation

Ollama was not available in the build environment, so the questions were produced by the
repository's deterministic, fact-grounded offline engine (each question derives from the
topic's verified catalogue concepts and fact card; `kind: "FACT_DERIVED"`).
To regenerate with a real model: `ollama pull gemma3:4b` then
`node scripts/generate.mjs --engine ollama --model gemma3:4b --target 40 --force && node scripts/build-data.mjs`.
