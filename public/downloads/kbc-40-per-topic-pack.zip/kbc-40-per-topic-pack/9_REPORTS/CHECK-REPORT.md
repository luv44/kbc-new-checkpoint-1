# Check report

Everything in this pack was measured from the built data, not estimated.

| Check | Expected | Found | Result |
| --- | ---: | ---: | --- |
| Subjects | 26 | 26 | PASS |
| Chapters | 82 | 82 | PASS |
| Topics | 345 | 345 | PASS |
| Questions | 13,800 | 13800 | PASS |
| Topics with exactly 40 questions | 345 | 345 | PASS |
| SI-unit MCQs | 400 | 400 | PASS |
| SI-unit questions in preserved bank | 0 | 0 | PASS |
| Exam profiles | 10 | 10 | PASS |
| Chapter JSON files | 82 | 82 | PASS |
| Exam JSON files | 591 | 591 | PASS |
| Files in this pack | — | 749 | — |

## Question counts by subject

| Subject | Topics | Questions |
| --- | ---: | ---: |
| S01 · India Basics & Physical Geography | 13 | 520 |
| S02 · Current Affairs & Contemporary Events | 11 | 440 |
| S03 · Ancient Indian History & Archaeology | 30 | 1200 |
| S04 · Medieval & Modern Indian History | 32 | 1280 |
| S05 · Indian Polity & Constitutional Framework | 17 | 680 |
| S06 · Governance, Panchayati Raj & Administration | 17 | 680 |
| S07 · Indian Economy, Banking & Public Finance | 16 | 640 |
| S08 · World Geography & Physical Landforms | 18 | 720 |
| S09 · Environment, Ecology & Biodiversity | 13 | 520 |
| S10 · General Science: Physics | 14 | 560 |
| S11 · General Science: Chemistry | 10 | 400 |
| S12 · Biology & Human Physiology | 24 | 960 |
| S13 · Information Technology & Computer Science | 10 | 400 |
| S14 · Space Science, Astronomy & ISRO Missions | 7 | 280 |
| S15 · World History & Major Revolutions | 9 | 360 |
| S16 · International Organizations & Treaties | 9 | 360 |
| S17 · Indian Art, Architecture & Heritage | 8 | 320 |
| S18 · World & Indian Literature | 9 | 360 |
| S19 · Sports, Games & International Championships | 15 | 600 |
| S20 · Cinema, Theatre & Performing Arts | 8 | 320 |
| S21 · Awards, Honors & National Distinctions | 8 | 320 |
| S22 · World Religions & Philosophies | 7 | 280 |
| S23 · Global Currencies, Trade & Commerce | 12 | 480 |
| S24 · Defence Forces, Paramilitary & Security | 9 | 360 |
| S25 · Visual & Identification GK | 9 | 360 |
| S26 · Metrology, SI Units & Standard Measures | 10 | 400 |

## Questions by exam

| Exam | Subjects | Questions | CSV in `by-exam/` |
| --- | ---: | ---: | --- |
| ALL (all) | 26 | 13800 | `all.csv` |
| KBC (kbc) | 26 | 13800 | `all.csv` (shared with all) |
| UPSC CSE (upsc-cse) | 25 | 13400 | `upsc-cse.csv` |
| HCS (hcs) | 25 | 13400 | `upsc-cse.csv` (shared with upsc-cse) |
| SSC CGL (ssc-cgl) | 26 | 13800 | `all.csv` (shared with all) |
| RRB NTPC (railway-ntpc) | 24 | 13080 | `railway-ntpc.csv` |
| SBI PO (sbi-po) | 9 | 4720 | `sbi-po.csv` |
| IBPS PO (ibps-po) | 9 | 4720 | `sbi-po.csv` (shared with sbi-po) |
| RBI Grade B (rbi-grade-b) | 8 | 4320 | `rbi-grade-b.csv` |
| APFC (apfc) | 8 | 4320 | `rbi-grade-b.csv` (shared with rbi-grade-b) |
